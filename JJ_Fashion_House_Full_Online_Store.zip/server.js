require("dotenv").config();

const express = require("express");
const path = require("path");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "replace-this-secret-before-production";

const db = new Database(path.join(__dirname, "data", "store.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price INTEGER NOT NULL DEFAULT 0,
  old_price INTEGER DEFAULT 0,
  image TEXT DEFAULT '',
  description TEXT DEFAULT '',
  sizes TEXT DEFAULT 'S,M,L,XL',
  stock INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  note TEXT DEFAULT '',
  items_json TEXT NOT NULL,
  subtotal INTEGER NOT NULL,
  delivery INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'Cash on Delivery',
  status TEXT NOT NULL DEFAULT 'Pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);

function seed() {
  const adminUser = process.env.ADMIN_USER || "J.JFashionHouse";
  const adminPass = process.env.ADMIN_PASS || "CHANGE_ME";
  const exists = db.prepare("SELECT id FROM admins WHERE username=?").get(adminUser);
  if (!exists) {
    const hash = bcrypt.hashSync(adminPass, 12);
    db.prepare("INSERT INTO admins(username,password_hash) VALUES(?,?)").run(adminUser, hash);
  }
  const count = db.prepare("SELECT COUNT(*) c FROM products").get().c;
  if (!count) {
    const demo = [
      ["Classic Panjabi", "Panjabi", 1490, 1790, "https://images.unsplash.com/photo-1583391733956-6c78276477e2?auto=format&fit=crop&w=900&q=80", "Elegant everyday panjabi.", "M,L,XL,XXL", 20],
      ["Premium Panjabi", "Panjabi", 2190, 2590, "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=900&q=80", "Premium festive style.", "M,L,XL,XXL", 12],
      ["Ladies Three Piece", "Three Piece", 1890, 2290, "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=900&q=80", "Comfortable boutique three-piece.", "Free Size", 15],
      ["Cotton Shirt", "Shirt", 990, 1190, "https://images.unsplash.com/photo-1602810319428-019690571b5b?auto=format&fit=crop&w=900&q=80", "Soft cotton casual shirt.", "M,L,XL,XXL", 25]
    ];
    const stmt = db.prepare("INSERT INTO products(name,category,price,old_price,image,description,sizes,stock) VALUES(?,?,?,?,?,?,?,?)");
    const tx = db.transaction(() => demo.forEach(p => stmt.run(...p)));
    tx();
  }
  const defaults = {
    store_name: process.env.STORE_NAME || "J.J Fashion House",
    phone: "+880 1631220611",
    whatsapp: process.env.WHATSAPP || "8801631220611",
    email: "iq6952iqbal@gmail.com",
    address: "Renata Road, Naya Para Bazar, Bhawal Mirzapur, Gazipur Sadar, Dhaka",
    hours: "08 AM – 10 PM",
    delivery_charge: "80",
    facebook: "https://www.facebook.com/share/1Gbw26goRJ/?mibextid=wwXIfr"
  };
  const put = db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)");
  Object.entries(defaults).forEach(([k,v]) => put.run(k,v));
}
seed();

app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/api/login", rateLimit({ windowMs: 15*60*1000, limit: 20 }));
app.use("/api/orders", rateLimit({ windowMs: 15*60*1000, limit: 60 }));
app.use(express.static(path.join(__dirname, "public")));

function auth(req,res,next) {
  const token = (req.headers.authorization || "").replace(/^Bearer /, "");
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({error:"Unauthorized"});
  }
}
function settingsObject() {
  return Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x => [x.key,x.value]));
}

app.post("/api/login", (req,res) => {
  const {username,password} = req.body || {};
  const admin = db.prepare("SELECT * FROM admins WHERE username=?").get(username);
  if (!admin || !bcrypt.compareSync(password || "", admin.password_hash))
    return res.status(401).json({error:"Invalid username or password"});
  const token = jwt.sign({id:admin.id, username:admin.username}, JWT_SECRET, {expiresIn:"8h"});
  res.json({token, username:admin.username});
});

app.get("/api/products", (req,res) => {
  const rows = db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id DESC").all();
  res.json(rows);
});
app.get("/api/settings", (req,res) => res.json(settingsObject()));

app.post("/api/orders", (req,res) => {
  const {customer_name,phone,address,note="",items,payment_method="Cash on Delivery"} = req.body || {};
  if (!customer_name || !phone || !address || !Array.isArray(items) || !items.length)
    return res.status(400).json({error:"Please provide customer details and at least one item."});

  const clean = [];
  let subtotal = 0;
  for (const item of items) {
    const p = db.prepare("SELECT id,name,price,stock FROM products WHERE id=? AND active=1").get(Number(item.id));
    const qty = Math.max(1, Math.min(99, Number(item.qty)||1));
    if (!p) return res.status(400).json({error:"A selected product is unavailable."});
    if (qty > p.stock) return res.status(400).json({error:`Only ${p.stock} of ${p.name} is available.`});
    clean.push({id:p.id,name:p.name,price:p.price,qty,size:item.size||""});
    subtotal += p.price * qty;
  }
  const delivery = Number(settingsObject().delivery_charge || 0);
  const total = subtotal + delivery;
  const info = db.transaction(() => {
    const r = db.prepare(`INSERT INTO orders(customer_name,phone,address,note,items_json,subtotal,delivery,total,payment_method)
      VALUES(?,?,?,?,?,?,?,?,?)`).run(customer_name,phone,address,note,JSON.stringify(clean),subtotal,delivery,total,payment_method);
    const dec = db.prepare("UPDATE products SET stock=stock-? WHERE id=?");
    clean.forEach(i => dec.run(i.qty,i.id));
    return r.lastInsertRowid;
  })();
  res.status(201).json({order_id:info,total,delivery});
});

app.get("/api/admin/products", auth, (req,res) => res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/admin/products", auth, (req,res) => {
  const {name,category,price,old_price=0,image="",description="",sizes="S,M,L,XL",stock=0,active=1} = req.body || {};
  if (!name || !category || Number(price) < 0) return res.status(400).json({error:"Name, category and valid price are required."});
  const r = db.prepare(`INSERT INTO products(name,category,price,old_price,image,description,sizes,stock,active)
    VALUES(?,?,?,?,?,?,?,?,?)`).run(name,category,Number(price),Number(old_price)||0,image,description,sizes,Math.max(0,Number(stock)||0),active?1:0);
  res.status(201).json({id:r.lastInsertRowid});
});
app.put("/api/admin/products/:id", auth, (req,res) => {
  const {name,category,price,old_price=0,image="",description="",sizes="S,M,L,XL",stock=0,active=1} = req.body || {};
  db.prepare(`UPDATE products SET name=?,category=?,price=?,old_price=?,image=?,description=?,sizes=?,stock=?,active=? WHERE id=?`)
    .run(name,category,Number(price),Number(old_price)||0,image,description,sizes,Math.max(0,Number(stock)||0),active?1:0,Number(req.params.id));
  res.json({ok:true});
});
app.delete("/api/admin/products/:id", auth, (req,res) => {
  db.prepare("DELETE FROM products WHERE id=?").run(Number(req.params.id));
  res.json({ok:true});
});

app.get("/api/admin/orders", auth, (req,res) => {
  const rows = db.prepare("SELECT * FROM orders ORDER BY id DESC").all();
  res.json(rows.map(r => ({...r, items:JSON.parse(r.items_json)})));
});
app.patch("/api/admin/orders/:id", auth, (req,res) => {
  const allowed = ["Pending","Confirmed","Packed","Shipped","Delivered","Cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,Number(req.params.id));
  res.json({ok:true});
});
app.get("/api/admin/stats", auth, (req,res) => {
  const stats = {
    products: db.prepare("SELECT COUNT(*) c FROM products WHERE active=1").get().c,
    orders: db.prepare("SELECT COUNT(*) c FROM orders").get().c,
    pending: db.prepare("SELECT COUNT(*) c FROM orders WHERE status='Pending'").get().c,
    revenue: db.prepare("SELECT COALESCE(SUM(total),0) s FROM orders WHERE status!='Cancelled'").get().s
  };
  res.json(stats);
});
app.get("/api/admin/settings", auth, (req,res) => res.json(settingsObject()));
app.put("/api/admin/settings", auth, (req,res) => {
  const allowed = ["store_name","phone","whatsapp","email","address","hours","delivery_charge","facebook"];
  const put = db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  const tx = db.transaction(obj => allowed.forEach(k => { if (obj[k] !== undefined) put.run(k,String(obj[k])); }));
  tx(req.body || {});
  res.json(settingsObject());
});
app.post("/api/admin/password", auth, (req,res) => {
  const {currentPassword,newPassword} = req.body || {};
  if (!newPassword || newPassword.length < 10) return res.status(400).json({error:"New password must be at least 10 characters."});
  const admin = db.prepare("SELECT * FROM admins WHERE id=?").get(req.admin.id);
  if (!bcrypt.compareSync(currentPassword || "", admin.password_hash)) return res.status(400).json({error:"Current password is incorrect."});
  db.prepare("UPDATE admins SET password_hash=? WHERE id=?").run(bcrypt.hashSync(newPassword,12),req.admin.id);
  res.json({ok:true});
});

app.get("/admin", (req,res) => res.sendFile(path.join(__dirname,"admin","index.html")));
app.get("/admin/login", (req,res) => res.sendFile(path.join(__dirname,"admin","login.html")));

app.listen(PORT, () => console.log(`J.J Fashion House running on http://localhost:${PORT}`));
