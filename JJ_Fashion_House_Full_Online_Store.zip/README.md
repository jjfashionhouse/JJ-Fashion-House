# J.J Fashion House — Full Online Store

## Included
- Customer storefront with search, categories and cart
- Checkout and Cash on Delivery order creation
- SQLite database for products, orders and store settings
- Admin login with bcrypt password hashing
- Admin dashboard: sales stats, product management, order status management
- Store settings management
- Admin password change
- Rate limiting and security headers
- Responsive mobile design
- WhatsApp/contact information preconfigured for J.J Fashion House

## Setup
1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Set a strong `ADMIN_PASS` and a long random `JWT_SECRET`.
4. Run:
   npm install
   npm start
5. Open `http://localhost:3000`
6. Admin: `http://localhost:3000/admin/login`

## Production
Use HTTPS behind a reverse proxy, persistent backups for `data/store.db`, a managed server/hosting provider, and a real payment gateway if online payments are required.

The supplied admin password is intentionally NOT embedded in this ZIP. Set it privately in `.env`.
