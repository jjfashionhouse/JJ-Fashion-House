require("dotenv").config();

const express = require("express");
const path = require("path");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Pool } = require("pg");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) throw new Error("DATABASE_URL is required");
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters");
if (!process.env.ADMIN_PASS || process.env.ADMIN_PASS.length < 10) throw new Error("ADMIN_PASS must be at least 10 characters");

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "false" ? false : { rejectUnauthorized: false },
  max: Number(process.env.DB_POOL_MAX || 5),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

const schema = `
CREATE TABLE IF NOT EXISTS admins (
  id BIGSERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price INTEGER NOT NULL DEFAULT 0,
  old_price INTEGER NOT NULL DEFAULT 0,
  image TEXT DEFAULT '',
  description TEXT DEFAULT '',
  sizes TEXT DEFAULT 'S,M,L,XL',
  stock INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS orders (
  id BIGSERIAL PRIMARY KEY,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  note TEXT DEFAULT '',
  items_json TEXT NOT NULL,
  subtotal INTEGER NOT NULL,
  delivery INTEGER NOT NULL DEFAULT 0,
  total INTEGER NOT NULL,
  payment_method TEXT NOT NULL DEFAULT 'Cash on Delivery',
  status TEXT NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`;

async function initDb() {
  await pool.query(schema);

  const adminUser = process.env.ADMIN_USER || "J.JFashionHouse";
  const adminPass = process.env.ADMIN_PASS;
  const hash = await bcrypt.hash(adminPass, 12);
  await pool.query(
    `INSERT INTO admins(username,password_hash) VALUES($1,$2)
     ON CONFLICT(username) DO NOTHING`,
    [adminUser, hash]
  );

  const productCount = Number((await pool.query("SELECT COUNT(*)::int AS c FROM products")).rows[0].c);
  if (!productCount) {
    const demo = [
      ["Classic Panjabi", "Panjabi", 1490, 1790, "https://images.unsplash.com/photo-1583391733956-6c78276477e2?auto=format&fit=crop&w=900&q=80", "Elegant everyday panjabi.", "M,L,XL,XXL", 20],
      ["Premium Panjabi", "Panjabi", 2190, 2590, "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=900&q=80", "Premium festive style.", "M,L,XL,XXL", 12],
      ["Ladies Three Piece", "Three Piece", 1890, 2290, "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=900&q=80", "Comfortable boutique three-piece.", "Free Size", 15],
      ["Cotton Shirt", "Shirt", 990, 1190, "https://images.unsplash.com/photo-1602810319428-019690571b5b?auto=format&fit=crop&w=900&q=80", "Soft cotton casual shirt.", "M,L,XL,XXL", 25]
    ];
    for (const p of demo) {
      await pool.query(
        `INSERT INTO products(name,category,price,old_price,image,description,sizes,stock)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8)`, p
      );
    }
  }

  const defaults = {
    store_name: process.env.STORE_NAME || "J.J Fashion House",
    phone: "+880 1631220611",
    whatsapp: process.env.WHATSAPP || "8801631220611",
    email: "iq6952iqbal@gmail.com",
    address: "Renata Road, Naya Para Bazar, Bhawal Mirzapur, Gazipur Sadar, Dhaka",
    hours: "08 AM – 10 PM",
    delivery_charge: "80",
    facebook: "https://www.facebook.com/share/1Gbw26goRJ/?mibextid=wwXIfr"
  };
  for (const [k, v] of Object.entries(defaults)) {
    await pool.query(
      `INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO NOTHING`,
      [k, String(v)]
    );
  }
}

app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/api/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 20 }));
app.use("/api/orders", rateLimit({ windowMs: 15 * 60 * 1000, limit: 60 }));
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer /, "");
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Unauthorized" });
  }
}

async function settingsObject() {
  const { rows } = await pool.query("SELECT key,value FROM settings");
  return Object.fromEntries(rows.map(x => [x.key, x.value]));
}

app.post("/api/login", async (req, res, next) => {
  try {
    const { username, password } = req.body || {};
    const { rows } = await pool.query("SELECT * FROM admins WHERE username=$1", [username]);
    const admin = rows[0];
    if (!admin || !(await bcrypt.compare(password || "", admin.password_hash)))
      return res.status(401).json({ error: "Invalid username or password" });
    const token = jwt.sign({ id: admin.id, username: admin.username }, JWT_SECRET, { expiresIn: "8h" });
    res.json({ token, username: admin.username });
  } catch (e) { next(e); }
});

app.get("/api/products", async (req, res, next) => {
  try {
    const { rows } = await pool.query("SELECT * FROM products WHERE active=TRUE ORDER BY id DESC");
    res.json(rows);
  } catch (e) { next(e); }
});
app.get("/api/settings", async (req, res, next) => {
  try { res.json(await settingsObject()); } catch (e) { next(e); }
});

app.post("/api/orders", async (req, res, next) => {
  const { customer_name, phone, address, note = "", items, payment_method = "Cash on Delivery" } = req.body || {};
  if (!customer_name || !phone || !address || !Array.isArray(items) || !items.length)
    return res.status(400).json({ error: "Please provide customer details and at least one item." });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const clean = [];
    let subtotal = 0;
    for (const item of items) {
      const { rows } = await client.query(
        "SELECT id,name,price,stock FROM products WHERE id=$1 AND active=TRUE FOR UPDATE",
        [Number(item.id)]
      );
      const p = rows[0];
      const qty = Math.max(1, Math.min(99, Number(item.qty) || 1));
      if (!p) throw Object.assign(new Error("A selected product is unavailable."), { status: 400 });
      if (qty > p.stock) throw Object.assign(new Error(`Only ${p.stock} of ${p.name} is available.`), { status: 400 });
      clean.push({ id: Number(p.id), name: p.name, price: p.price, qty, size: item.size || "" });
      subtotal += p.price * qty;
    }
    const settings = await settingsObject();
    const delivery = Number(settings.delivery_charge || 0);
    const total = subtotal + delivery;
    const inserted = await client.query(
      `INSERT INTO orders(customer_name,phone,address,note,items_json,subtotal,delivery,total,payment_method)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
      [customer_name, phone, address, note, JSON.stringify(clean), subtotal, delivery, total, payment_method]
    );
    for (const i of clean) {
      await client.query("UPDATE products SET stock=stock-$1 WHERE id=$2", [i.qty, i.id]);
    }
    await client.query("COMMIT");
    res.status(201).json({ order_id: Number(inserted.rows[0].id), total, delivery });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(e.status || 500).json({ error: e.status ? e.message : "Could not place order." });
  } finally {
    client.release();
  }
});

app.get("/api/admin/products", auth, async (req, res, next) => {
  try { res.json((await pool.query("SELECT * FROM products ORDER BY id DESC")).rows); } catch (e) { next(e); }
});
app.post("/api/admin/products", auth, async (req, res, next) => {
  try {
    const { name, category, price, old_price = 0, image = "", description = "", sizes = "S,M,L,XL", stock = 0, active = true } = req.body || {};
    if (!name || !category || Number(price) < 0) return res.status(400).json({ error: "Name, category and valid price are required." });
    const r = await pool.query(
      `INSERT INTO products(name,category,price,old_price,image,description,sizes,stock,active)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
      [name, category, Number(price), Number(old_price) || 0, image, description, sizes, Math.max(0, Number(stock) || 0), Boolean(active)]
    );
    res.status(201).json({ id: Number(r.rows[0].id) });
  } catch (e) { next(e); }
});
app.put("/api/admin/products/:id", auth, async (req, res, next) => {
  try {
    const { name, category, price, old_price = 0, image = "", description = "", sizes = "S,M,L,XL", stock = 0, active = true } = req.body || {};
    await pool.query(
      `UPDATE products SET name=$1,category=$2,price=$3,old_price=$4,image=$5,description=$6,sizes=$7,stock=$8,active=$9 WHERE id=$10`,
      [name, category, Number(price), Number(old_price) || 0, image, description, sizes, Math.max(0, Number(stock) || 0), Boolean(active), Number(req.params.id)]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
});
app.delete("/api/admin/products/:id", auth, async (req, res, next) => {
  try { await pool.query("DELETE FROM products WHERE id=$1", [Number(req.params.id)]); res.json({ ok: true }); } catch (e) { next(e); }
});

app.get("/api/admin/orders", auth, async (req, res, next) => {
  try {
    const { rows } = await pool.query("SELECT * FROM orders ORDER BY id DESC");
    res.json(rows.map(r => ({ ...r, items: JSON.parse(r.items_json) })));
  } catch (e) { next(e); }
});
app.patch("/api/admin/orders/:id", auth, async (req, res, next) => {
  try {
    const allowed = ["Pending", "Confirmed", "Packed", "Shipped", "Delivered", "Cancelled"];
    if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid status" });
    await pool.query("UPDATE orders SET status=$1 WHERE id=$2", [req.body.status, Number(req.params.id)]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});
app.get("/api/admin/stats", auth, async (req, res, next) => {
  try {
    const [products, orders, pending, revenue] = await Promise.all([
      pool.query("SELECT COUNT(*)::int AS c FROM products WHERE active=TRUE"),
      pool.query("SELECT COUNT(*)::int AS c FROM orders"),
      pool.query("SELECT COUNT(*)::int AS c FROM orders WHERE status='Pending'"),
      pool.query("SELECT COALESCE(SUM(total),0)::int AS s FROM orders WHERE status!='Cancelled'")
    ]);
    res.json({
      products: products.rows[0].c,
      orders: orders.rows[0].c,
      pending: pending.rows[0].c,
      revenue: revenue.rows[0].s
    });
  } catch (e) { next(e); }
});
app.get("/api/admin/settings", auth, async (req, res, next) => {
  try { res.json(await settingsObject()); } catch (e) { next(e); }
});
app.put("/api/admin/settings", auth, async (req, res, next) => {
  try {
    const allowed = ["store_name", "phone", "whatsapp", "email", "address", "hours", "delivery_charge", "facebook"];
    for (const k of allowed) {
      if (req.body[k] !== undefined) {
        await pool.query(
          `INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value`,
          [k, String(req.body[k])]
        );
      }
    }
    res.json(await settingsObject());
  } catch (e) { next(e); }
});
app.post("/api/admin/password", auth, async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body || {};
    if (!newPassword || newPassword.length < 10) return res.status(400).json({ error: "New password must be at least 10 characters." });
    const { rows } = await pool.query("SELECT * FROM admins WHERE id=$1", [req.admin.id]);
    const admin = rows[0];
    if (!admin || !(await bcrypt.compare(currentPassword || "", admin.password_hash))) return res.status(400).json({ error: "Current password is incorrect." });
    await pool.query("UPDATE admins SET password_hash=$1 WHERE id=$2", [await bcrypt.hash(newPassword, 12), req.admin.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "admin", "index.html")));
app.get("/admin/login", (req, res) => res.sendFile(path.join(__dirname, "admin", "login.html")));

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "Server error" });
});

initDb()
  .then(() => {
    app.listen(PORT, "0.0.0.0", () => console.log(`J.J Fashion House running on port ${PORT}`));
  })
  .catch(err => {
    console.error("Database initialization failed:", err);
    process.exit(1);
  });
