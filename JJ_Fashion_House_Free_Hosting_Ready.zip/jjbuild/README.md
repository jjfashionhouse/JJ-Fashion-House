# J.J Fashion House — Free-Hosting Ready Online Store

This version is prepared for a free Render web service plus an external PostgreSQL database such as Supabase Free.

## Included
- Customer storefront with search, categories and cart
- Checkout and Cash on Delivery order creation
- Persistent PostgreSQL database for products, orders and store settings
- Secure admin login with bcrypt password hashing
- Admin dashboard: sales stats, product management and order status management
- Store settings management
- Admin password change
- Rate limiting and security headers
- Responsive mobile design
- WhatsApp, phone, email and Facebook integration
- Render `render.yaml` deployment blueprint

## Important free-hosting note
Render Free web services use an ephemeral filesystem, so the old SQLite version was not suitable for persistent orders/products. This version uses PostgreSQL instead. Render documents that free web services can be used for testing/hobby projects, spin down after 15 minutes of inactivity, and lose local filesystem changes on restart/redeploy/spin-down.

Supabase currently offers a Free plan with a PostgreSQL database up to 500 MB per project, but free projects are paused after one week of inactivity.

## Local setup
1. Install Node.js 18+.
2. Create a PostgreSQL database.
3. Copy `.env.example` to `.env`.
4. Set `DATABASE_URL`, `JWT_SECRET`, and your private `ADMIN_PASS`.
5. Run:
   npm install
   npm start
6. Open `http://localhost:3000`.
7. Admin: `http://localhost:3000/admin/login`.

## Render deployment
1. Put this folder in a GitHub repository.
2. In Render, choose **New → Web Service** and connect the repository, or use the included `render.yaml` blueprint.
3. Use `npm install` as the build command and `npm start` as the start command.
4. Add these environment variables/secrets:
   - `DATABASE_URL` = your PostgreSQL connection string
   - `JWT_SECRET` = a long random secret (32+ characters)
   - `ADMIN_USER` = `J.JFashionHouse`
   - `ADMIN_PASS` = your private admin password (10+ characters)
   - `DATABASE_SSL` = `true`
5. Deploy.

Render gives the service an `onrender.com` URL. Custom domains are supported if you later purchase a domain such as `jjfashionhouse.com`.

## Security
- Do not put your admin password, database password, or JWT secret into GitHub.
- Keep `.env` private.
- Change the admin password from the dashboard after first login if needed.
- For a real production store, use a paid/reliable hosting and database plan with backups and monitoring.
